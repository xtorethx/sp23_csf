Hannah Qu hqu6@jhu.edu
Dru Zheng dzheng12@jhu.edu

We split up the work equally. We wrote and edited most of the functions
and main together and checked each others code.