Hannah Qu
Dru Zheng

We split up the functions. Hannah implemented hex_format_byte_as_hex and hex_to_printable in C along
with the assembly implementations of hex_to_printable and hex_format_byte_as_hex. Dru implemented hex_read,
hex_wrote_string, and hex_format_offset in C.