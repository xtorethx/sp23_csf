#ifndef CACHESIMFUNCS_H
#define CACHESIMFUNCS_H

#include <iostream>
#include <string>
#include <vector>
#include <map>
#include "cachesimfuncs.h"

//TO DO: Write Functions


#endif